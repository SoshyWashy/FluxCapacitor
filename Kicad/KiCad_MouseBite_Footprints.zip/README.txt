KiCad mouse-bite footprints

MouseBite_4xD0.6mm_P1.0mm
- 4 holes
- 0.60 mm NPTH drill
- 1.00 mm pitch
- 3.60 mm overall row span
- Fits a 4.00 mm tab, but uses only 4 holes.

MouseBite_5xD0.6mm_P1.0mm
- 5 holes
- 0.60 mm NPTH drill
- 1.00 mm pitch
- 4.60 mm overall row span
- Better suited to a 5.00 mm tab.

Installation:
1. Create or open a project footprint library ending in .pretty.
2. Copy the desired .kicad_mod file into that folder.
3. In KiCad, open Preferences > Manage Footprint Libraries.
4. Add the .pretty library if it is not already registered.
5. Place the footprint and align the intended fracture line through the hole centers.

Verify the drill and board outline in Gerber Viewer before ordering.
